package com.example.data

import android.content.Context
import com.example.BuildConfig

object SupabaseConfig {
    private const val PREF_NAME = "supabase_config_prefs"
    private const val KEY_URL = "supabase_url"
    private const val KEY_KEY = "supabase_anon_key"

    fun getUrl(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val savedUrl = prefs.getString(KEY_URL, null)
        if (!savedUrl.isNull_or_blank()) return savedUrl.orEmpty().trim()

        // Fallback to BuildConfig if provided via .env
        return try {
            val configUrl = BuildConfig::class.java.getField("SUPABASE_URL").get(null) as? String
            if (!configUrl.isNull_or_blank() && configUrl != "https://YOUR_SUPABASE_PROJECT_REF.supabase.co") {
                configUrl.orEmpty().trim()
            } else ""
        } catch (e: Exception) {
            ""
        }
    }

    fun getAnonKey(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val savedKey = prefs.getString(KEY_KEY, null)
        if (!savedKey.isNull_or_blank()) return savedKey.orEmpty().trim()

        // Fallback to BuildConfig if provided via .env
        return try {
            val configKey = BuildConfig::class.java.getField("SUPABASE_ANON_KEY").get(null) as? String
            if (!configKey.isNull_or_blank() && configKey != "YOUR_SUPABASE_ANON_KEY") {
                configKey.orEmpty().trim()
            } else ""
        } catch (e: Exception) {
            ""
        }
    }

    fun saveConfig(context: Context, url: String, anonKey: String) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_URL, url.trim())
            .putString(KEY_KEY, anonKey.trim())
            .apply()
    }

    fun isConfigured(context: Context): Boolean {
        val url = getUrl(context)
        val key = getAnonKey(context)
        return url.isNotBlank() && key.isNotBlank() && url.startsWith("http")
    }

    private fun String?.isNull_or_blank(): Boolean {
        return this == null || this.trim().isEmpty()
    }
}
