package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.LocalProfileEntity
import com.example.ui.theme.AccentGold
import com.example.ui.theme.ColorAdminMgmt
import com.example.ui.theme.ColorGyanSadhana
import com.example.ui.theme.ColorGyanSetu
import com.example.ui.theme.ColorNMMS
import com.example.ui.theme.ColorNavodaya
import com.example.ui.theme.ColorTET1
import com.example.ui.theme.EmeraldIconBg
import com.example.ui.theme.GyanSadhanaBg
import com.example.ui.theme.GyanSadhanaText
import com.example.ui.theme.GyanSetuBg
import com.example.ui.theme.GyanSetuText
import com.example.ui.theme.IndigoIconBg
import com.example.ui.theme.NavodayaBg
import com.example.ui.theme.NavodayaText
import com.example.ui.theme.NmmsBg
import com.example.ui.theme.NmmsText
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryDarkBlue
import com.example.ui.theme.Tet1Bg
import com.example.ui.theme.Tet1Text

@Composable
fun AdminDashboardScreen(
    adminProfile: LocalProfileEntity,
    totalStudents: Int,
    totalTests: Int,
    totalNotifications: Int,
    totalAdmins: Int,
    onNavStudents: () -> Unit,
    onNavExamTypes: () -> Unit,
    onNavNotifications: () -> Unit,
    onNavAdminMgmt: () -> Unit,
    onNavResults: () -> Unit,
    onOpenSettings: () -> Unit,
    onLogout: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
    ) {
        // --- Header Section matching Design HTML ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = PrimaryBlue,
                    shape = RoundedCornerShape(bottomStart = 36.dp, bottomEnd = 36.dp)
                )
                .padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 36.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Badge Avatar with "TM"
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color.White),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "TM",
                                color = PrimaryBlue,
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = "TEST MITRA",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = if (adminProfile.isMainAdmin) "Main Admin Control" else "Section Admin",
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Row {
                        IconButton(
                            onClick = onOpenSettings,
                            modifier = Modifier.testTag("admin_settings_icon")
                        ) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
                        }

                        IconButton(
                            onClick = onLogout,
                            modifier = Modifier.testTag("admin_logout_icon")
                        ) {
                            Icon(Icons.Default.ExitToApp, contentDescription = "Logout", tint = Color.White)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "નમસ્તે, એડમિન",
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "સ્વાગત છે, ${adminProfile.name}",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // --- Stat Cards Section (Vibrant Design) ---
        Column(modifier = Modifier.padding(horizontal = 20.dp)) {
            Spacer(modifier = Modifier.height(-12.dp)) // Slight overlap

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Stat 1: Total Students
                StatCard(
                    title = "કુલ વિદ્યાર્થી",
                    value = totalStudents.toString(),
                    icon = Icons.Default.People,
                    badgeBg = IndigoIconBg,
                    badgeTint = ColorNavodaya,
                    modifier = Modifier.weight(1f)
                )

                // Stat 2: Total Tests
                StatCard(
                    title = "કુલ ટેસ્ટ",
                    value = totalTests.toString(),
                    icon = Icons.Default.Assignment,
                    badgeBg = EmeraldIconBg,
                    badgeTint = ColorGyanSetu,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // --- Exam Types Horizontal Carousel Section ---
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "પરીક્ષાના પ્રકાર (Exam Types)",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B)
                )
                Text(
                    text = "બધું જુઓ",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryBlue,
                    modifier = Modifier.clickable { onNavExamTypes() }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(end = 12.dp)
            ) {
                item {
                    ExamTypePill(
                        title = "નવોદય",
                        emoji = "🏫",
                        bgColor = NavodayaBg,
                        textColor = NavodayaText,
                        onClick = onNavExamTypes
                    )
                }
                item {
                    ExamTypePill(
                        title = "NMMS",
                        emoji = "🎓",
                        bgColor = NmmsBg,
                        textColor = NmmsText,
                        onClick = onNavExamTypes
                    )
                }
                item {
                    ExamTypePill(
                        title = "TET 1",
                        emoji = "📚",
                        bgColor = Tet1Bg,
                        textColor = Tet1Text,
                        onClick = onNavExamTypes
                    )
                }
                item {
                    ExamTypePill(
                        title = "જ્ઞાન સેતુ",
                        emoji = "🖋️",
                        bgColor = GyanSetuBg,
                        textColor = GyanSetuText,
                        onClick = onNavExamTypes
                    )
                }
                item {
                    ExamTypePill(
                        title = "જ્ઞાન સાધના",
                        emoji = "🏆",
                        bgColor = GyanSadhanaBg,
                        textColor = GyanSadhanaText,
                        onClick = onNavExamTypes
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // --- Quick Menu Section ---
            Text(
                text = "ઝડપી મેનુ (Quick Menu)",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1E293B)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickMenuItem(
                    title = "વિદ્યાર્થીઓ મેનેજમેન્ટ",
                    subtitle = "વિદ્યાર્થીઓ ઉમેરો અથવા સ્ટેટસ બદલો",
                    icon = Icons.Default.People,
                    iconBg = PrimaryBlue,
                    onClick = onNavStudents,
                    tag = "btn_students_mgmt"
                )

                QuickMenuItem(
                    title = "પરીક્ષાના પ્રકાર & ટેસ્ટ",
                    subtitle = "ટેસ્ટ્સ અને પ્રશ્નો મેનેજ કરો",
                    icon = Icons.Default.Assignment,
                    iconBg = ColorNMMS,
                    onClick = onNavExamTypes,
                    tag = "btn_exam_types"
                )

                QuickMenuItem(
                    title = "સૂચનાઓ (Notifications)",
                    subtitle = "વિદ્યાર્થીઓ માટે નવી સૂચનાઓ મૂકો",
                    icon = Icons.Default.Notifications,
                    iconBg = AccentGold,
                    onClick = onNavNotifications,
                    tag = "btn_notifications_mgmt"
                )

                if (adminProfile.isMainAdmin) {
                    QuickMenuItem(
                        title = "એડમિન મેનેજમેન્ટ",
                        subtitle = "નવા એડમિન એકાઉન્ટ્સ બનાવો",
                        icon = Icons.Default.Security,
                        iconBg = ColorAdminMgmt,
                        onClick = onNavAdminMgmt,
                        tag = "btn_admin_mgmt"
                    )
                }

                QuickMenuItem(
                    title = "પરિણામ & એનાલિટિક્સ",
                    subtitle = "બધા વિદ્યાર્થીઓના સ્કોર રિપોર્ટ જુઓ",
                    icon = Icons.Default.Assessment,
                    iconBg = ColorGyanSetu,
                    onClick = onNavResults,
                    tag = "btn_results_mgmt"
                )
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    icon: ImageVector,
    badgeBg: Color,
    badgeTint: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(badgeBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = badgeTint,
                    modifier = Modifier.size(26.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = title.uppercase(),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF94A3B8),
                letterSpacing = 0.5.sp
            )

            Text(
                text = value,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF1E293B)
            )
        }
    }
}

@Composable
private fun ExamTypePill(
    title: String,
    emoji: String,
    bgColor: Color,
    textColor: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(110.dp)
            .height(96.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(text = emoji, fontSize = 26.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = textColor
            )
        }
    }
}

@Composable
private fun QuickMenuItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconBg: Color,
    onClick: () -> Unit,
    tag: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(tag),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(iconBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(
                        text = title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E293B)
                    )
                    Text(
                        text = subtitle,
                        fontSize = 12.sp,
                        color = Color(0xFF64748B)
                    )
                }
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = Color(0xFFCBD5E1),
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

